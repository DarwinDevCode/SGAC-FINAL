package org.uteq.sgacfinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SgacFinalApplication {

    public static void main(String[] args) {
        SpringApplication.run(SgacFinalApplication.class, args);
    }

}

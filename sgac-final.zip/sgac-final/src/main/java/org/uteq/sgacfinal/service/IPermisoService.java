package org.uteq.sgacfinal.service;

import org.uteq.sgacfinal.dto.PermisoDTO;
import java.util.List;

public interface IPermisoService {
    List<PermisoDTO> obtenerPermisos();
}

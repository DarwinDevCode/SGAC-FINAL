@FunctionalInterface
public interface OperacionesBasicas {
    int Operacion(int a, int b);
}



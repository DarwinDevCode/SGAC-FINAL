public interface Operaciones {
    float Operacion(int a, int b);
}

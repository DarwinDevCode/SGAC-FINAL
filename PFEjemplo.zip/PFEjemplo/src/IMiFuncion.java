@FunctionalInterface
interface MiFuncion {
    void ejecutar();
}

@FunctionalInterface
public interface Acciones {
    void accion();
}


